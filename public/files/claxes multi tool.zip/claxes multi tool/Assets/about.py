# about.py

def set_text_color(color):
    colors = {
        'green': '\033[92m',
        'white': '\033[0m'
    }
    return colors.get(color, '\033[0m')

def main():
    print(set_text_color('green') + "===============================")
    print("       About Claxes Tool")
    print("===============================")
    print("Version: 1.0")
    print("Author: Clax")
    print("Hmm looks like your browsing da files")
    print(set_text_color('white'))  # Reset color to white

if __name__ == "__main__":
    main()
