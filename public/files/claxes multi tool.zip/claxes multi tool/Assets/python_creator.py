import os

def create_python_script(script_name, content, path):
    file_path = os.path.join(path, f"{script_name}.pyw" if script_name == "Tic Tac Toe" else f"{script_name}.py")
    with open(file_path, 'w') as file:
        file.write(content)
    print(f"Script '{script_name}.pyw' created successfully at '{file_path}'." if script_name == "Tic Tac Toe" else f"Script '{script_name}.py' created successfully at '{file_path}'.")

def generate_number_guessing_game_script():
    return '''
import random

def guess_number():
    print("Think of a number between 0 and 20, and I will try to guess it.")
    low = 0
    high = 20
    feedback = ""
    
    while feedback != "c":
        if low != high:
            guess = random.randint(low, high)
        else:
            guess = low
        feedback = input(f"Is {guess} too high (H), too low (L), or correct (C)? ").lower()
        if feedback == "h":
            high = guess - 1
        elif feedback == "l":
            low = guess + 1
    
    print(f"I guessed it! Your number was {guess}.")
    if input("Do you want to play again? (yes/no): ").lower() == "yes":
        guess_number()

if __name__ == "__main__":
    guess_number()
    '''

def generate_calculator_script():
    return '''
def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

def multiply(x, y):
    return x * y

def divide(x, y):
    if y == 0:
        return "Error! Division by zero."
    return x / y

def calculator():
    print("Select operation:")
    print("1. Add")
    print("2. Subtract")
    print("3. Multiply")
    print("4. Divide")

    while True:
        choice = input("Enter choice(1/2/3/4): ")
        if choice in ['1', '2', '3', '4']:
            num1 = float(input("Enter first number: "))
            num2 = float(input("Enter second number: "))

            if choice == '1':
                print(f"{num1} + {num2} = {add(num1, num2)}")
            elif choice == '2':
                print(f"{num1} - {num2} = {subtract(num1, num2)}")
            elif choice == '3':
                print(f"{num1} * {num2} = {multiply(num1, num2)}")
            elif choice == '4':
                print(f"{num1} / {num2} = {divide(num1, num2)}")
        else:
            print("Invalid Input")

        if input("Do you want to perform another calculation? (yes/no): ").lower() != "yes":
            break

if __name__ == "__main__":
    calculator()
    '''

def generate_tic_tac_toe_script():
    return '''
import tkinter as tk
from tkinter import messagebox
import random

class TicTacToe:
    def __init__(self, root):
        self.root = root
        self.root.title("Tic Tac Toe")
        self.player = "X"
        self.bot = "O"
        self.board = [" " for _ in range(9)]
        self.buttons = [tk.Button(root, text=" ", font="Arial 20", width=5, height=2, 
                                  command=lambda i=i: self.on_button_click(i)) for i in range(9)]
        
        for i, button in enumerate(self.buttons):
            button.grid(row=i//3, column=i%3)
        
        self.reset_button = tk.Button(root, text="Reset", command=self.reset_game)
        self.reset_button.grid(row=3, column=0, columnspan=3)
        
        self.update_status()

    def on_button_click(self, index):
        if self.board[index] == " ":
            self.board[index] = self.player
            self.update_buttons()
            if self.check_winner(self.player):
                messagebox.showinfo("Tic Tac Toe", f"Player {self.player} wins!")
                self.reset_game()
            elif " " not in self.board:
                messagebox.showinfo("Tic Tac Toe", "It's a tie!")
                self.reset_game()
            else:
                self.bot_move()
    
    def bot_move(self):
        empty_cells = [i for i, cell in enumerate(self.board) if cell == " "]
        index = random.choice(empty_cells)
        self.board[index] = self.bot
        self.update_buttons()
        if self.check_winner(self.bot):
            messagebox.showinfo("Tic Tac Toe", "Bot wins!")
            self.reset_game()
        elif " " not in self.board:
            messagebox.showinfo("Tic Tac Toe", "It's a tie!")
            self.reset_game()

    def update_buttons(self):
        for i, button in enumerate(self.buttons):
            button.config(text=self.board[i])

    def check_winner(self, player):
        win_conditions = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],  # Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8],  # Columns
            [0, 4, 8], [2, 4, 6]  # Diagonals
        ]
        for condition in win_conditions:
            if all(self.board[i] == player for i in condition):
                return True
        return False

    def reset_game(self):
        self.board = [" " for _ in range(9)]
        self.update_buttons()

    def update_status(self):
        pass  # Optionally update status or additional UI elements

def main():
    root = tk.Tk()
    game = TicTacToe(root)
    root.mainloop()

if __name__ == "__main__":
    main()
    '''

def python_creator_menu():
    while True:
        print("Python Creator Menu:")
        print("[1] -> Number Guessing Game")
        print("[2] -> Calculator")
        print("[3] -> Tic Tac Toe")
        print("[0] -> Exit")
        
        choice = input("Enter your choice: ")
        
        if choice == '0':
            break
        elif choice == '1':
            print("Creating Number Guessing Game script...")
            save_path = input("Enter the path where you want to save the script: ")
            script_name = input("Enter script name (without .py extension): ")
            create_python_script(script_name, generate_number_guessing_game_script(), save_path)
        elif choice == '2':
            print("Creating Calculator script...")
            save_path = input("Enter the path where you want to save the script: ")
            script_name = input("Enter script name (without .py extension): ")
            create_python_script(script_name, generate_calculator_script(), save_path)
        elif choice == '3':
            print("Creating Tic Tac Toe script...")
            save_path = input("Enter the path where you want to save the script: ")
            script_name = "Tic Tac Toe"
            create_python_script(script_name, generate_tic_tac_toe_script(), save_path)
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    python_creator_menu()
