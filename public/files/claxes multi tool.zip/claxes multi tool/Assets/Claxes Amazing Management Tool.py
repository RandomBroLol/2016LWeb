import os
import ctypes
import requests
import socket
import getpass
from PIL import Image
import subprocess

def set_text_color(color):
    colors = {
        'green': '\033[92m',
        'red': '\033[91m',
        'blue': '\033[94m',
        'yellow': '\033[93m',
        'white': '\033[0m'
    }
    return colors.get(color, '\033[0m')

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def get_username():
    return getpass.getuser()

def print_header():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(set_text_color('blue') + "=" * 80)
    print(set_text_color('yellow') + " ▄████▄   ██▓    ▄▄▄      ▒██   ██▒   ▄▄▄█████▓ ▒█████   ▒█████   ██▓    ")
    print(set_text_color('yellow') + "▒██▀ ▀█  ▓██▒   ▒████▄    ▒▒ █ █ ▒░   ▓  ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒    ")
    print(set_text_color('yellow') + "▒▓█    ▄ ▒██░   ▒██  ▀█▄  ░░  █   ░   ▒ ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░    ")
    print(set_text_color('yellow') + "▒▓▓▄ ▄██▒▒██░   ░██▄▄▄▄██  ░ █ █ ▒    ░ ▓██▓ ░ ▒██   ██░▒██   ██░▒██░    ")
    print(set_text_color('yellow') + "▒ ▓███▀ ░░██████▒▓█   ▓██▒▒██▒ ▒██▒     ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒")
    print(set_text_color('yellow') + "░ ░▒ ▒  ░░ ▒░▓  ░▒▒   ▓▒█░▒▒ ░ ░▓ ░     ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░")
    print(set_text_color('yellow') + "  ░  ▒   ░ ░ ▒  ░ ▒   ▒▒ ░░░   ░▒ ░       ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░")
    print(set_text_color('yellow') + "░          ░ ░    ░   ▒    ░    ░       ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░   ")
    print(set_text_color('yellow') + "░ ░          ░  ░     ░  ░ ░    ░                  ░ ░      ░ ░      ░  ░")
    print(set_text_color('yellow') + "░                                                                         ")
    print(set_text_color('blue') + "=" * 80)
    print(set_text_color('white'))

def add_user():
    print(set_text_color('green'), end='')
    username = input("Enter the username: ")
    user_type = input("Enter user type (normal/administrator): ").strip().lower()
    while user_type not in ['normal', 'administrator']:
        print(set_text_color('red') + "Invalid user type. Please enter 'normal' or 'administrator'.")
        user_type = input("Enter user type (normal/administrator): ").strip().lower()
    
    password = input("Enter the password: ")
    result = subprocess.run(['net', 'user', username, password, '/add'], capture_output=True, text=True)
    if result.returncode == 0:
        print(f"User {username} ({user_type}) has been added successfully.")
    else:
        print(f"Failed to add user {username}.")
        print(result.stdout)
    input(set_text_color('white') + "Press Enter to return to the menu...")

def list_users():
    print(set_text_color('green'), end='')
    print("Listing all users:")
    subprocess.run(['net', 'user'])
    input(set_text_color('white') + "Press Enter to return to the menu...")

def change_password():
    print(set_text_color('green'), end='')
    username = input("Enter the username: ")
    password = input("Enter the new password: ")
    result = subprocess.run(['net', 'user', username, password], capture_output=True, text=True)
    if result.returncode == 0:
        print(f"Password for user {username} has been changed successfully.")
    else:
        print(f"Failed to change password for user {username}.")
        print(result.stdout)
    input(set_text_color('white') + "Press Enter to return to the menu...")

def delete_user():
    print(set_text_color('green'), end='')
    username = input("Enter the username: ")
    result = subprocess.run(['net', 'user', username, '/delete'], capture_output=True, text=True)
    if result.returncode == 0:
        print(f"User {username} has been deleted successfully.")
    else:
        print(f"Failed to delete user {username}.")
        print(result.stdout)
    input(set_text_color('white') + "Press Enter to return to the menu...")

def delete_system32():
    print(set_text_color('red'), end='')
    confirm = input("WARNING: You are about to delete the System32 directory. This will render your operating system non-functional. Are you sure you want to continue? (yes/no): ")
    if confirm.lower() == 'yes':
        print("Deleting System32 directory...")
        print("(This is a simulation. Uncomment the dangerous command below to actually delete System32)")
        # subprocess.run(['rd', '/s', '/q', 'C:\\Windows\\System32'])
        print("System32 directory deleted.")
    else:
        print("Operation cancelled.")
    input(set_text_color('white') + "Press Enter to return to the menu...")

def dancing_parrot():
    print(set_text_color('green'), end='')
    print("Enjoy the dancing parrot!")
    subprocess.run(['curl', 'parrot.live'])
    input(set_text_color('white') + "Press Enter to return to the menu...")

def open_kali_linux_download_page():
    print(set_text_color('green'), end='')
    print("Opening Kali Linux download page...")
    subprocess.run(['start', 'https://www.kali.org/downloads/'])
    input(set_text_color('white') + "Press Enter to return to the menu...")

def list_wifi_passwords():
    print(set_text_color('green'), end='')
    print("Retrieving saved Wi-Fi networks and passwords...")
    wifi_profiles = subprocess.check_output('netsh wlan show profiles', shell=True).decode()
    profiles = [line.split(":")[1].strip() for line in wifi_profiles.split('\n') if "Profile" in line]

    for profile in profiles:
        try:
            wifi_details = subprocess.check_output(f'netsh wlan show profile name="{profile}" key=clear', shell=True).decode()
            password_line = [line for line in wifi_details.split('\n') if "Key Content" in line]
            password = password_line[0].split(":")[1].strip() if password_line else "No password found"
            print(f"SSID: {profile}")
            print(f"Password: {password}")
        except subprocess.CalledProcessError:
            print(f"Failed to retrieve details for SSID: {profile}")
    input(set_text_color('white') + "Press Enter to return to the menu...")

def send_message_to_webhook():
    print(set_text_color('green'), end='')
    webhook_url = input("Enter the webhook URL: ")
    message = input("Enter the message: ")
    data = {"content": message}
    response = requests.post(webhook_url, json=data)
    if response.status_code == 204:
        print("Message sent successfully.")
    else:
        print(f"Failed to send message. Status code: {response.status_code}")
    input(set_text_color('white') + "Press Enter to return to the menu...")

def send_image_to_webhook():
    print(set_text_color('green'), end='')
    webhook_url = input("Enter the webhook URL: ")
    image_path = input("Enter the path to the image: ")
    with open(image_path, 'rb') as f:
        files = {"file": f}
        response = requests.post(webhook_url, files=files)
    if response.status_code == 204:
        print("Image sent successfully.")
    else:
        print(f"Failed to send image. Status code: {response.status_code}")
    input(set_text_color('white') + "Press Enter to return to the menu...")

def show_cool_websites():
    print(set_text_color('green'), end='')
    websites = [
        "https://roblox.mk/create/CreatorHome/generator --roblox phishing creator",
        "https://grabify.link/ --IP phishing creator",
        "https://doxbin.net/ --DoxBin",
        "https://ddosnow.com/ --DDoS website",
        "https://sqlmap.org --SQL Map"
    ]
    print("Cool Websites:")
    for website in websites:
        print(website)
    input(set_text_color('white') + "Press Enter to return to the menu...")

def show_ip_addresses():
    print(set_text_color('green'), end='')
    hostname = socket.gethostname()
    private_ip = socket.gethostbyname(hostname)
    public_ip = requests.get('https://api.ipify.org').text
    print(f"Private IP Address: {private_ip}")
    print(f"Public IP Address: {public_ip}")
    input(set_text_color('white') + "Press Enter to return to the menu...")

def about_tool():
    print(set_text_color('blue'), end='')
    print("Claxes Amazing Management Tool")
    print("Version: 2.0")
    print("This tool provides various functionalities for system management and utility tasks.")
    print("This tool is a private copy")
    input(set_text_color('white') + "Press Enter to return to the menu...")

def log_out_user():
    print(set_text_color('green'), end='')
    username = input("Enter the username of the user to log out: ")
    try:
        subprocess.run(['logoff', username], check=True)
        print(f"Successfully logged out user: {username}")
    except subprocess.CalledProcessError as e:
        print(f"Failed to log out user: {username}. Error: {e}")
    input(set_text_color('white') + "Press Enter to return to the menu...")

def My_Discord_Token():
    print(set_text_color('green'), end='')
    script_dir = os.path.dirname(os.path.realpath(__file__))
    python_creator_script = os.path.join(script_dir, 'My-Discord-Token.py')
    
    try:
        subprocess.run(['python', python_creator_script], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Failed to open My-Discord-Token.py: {e}")
    
    input(set_text_color('white') + "Press Enter to return to the menu...")

def browser():
    print(set_text_color('green'), end='')
    print("Select a search engine:")
    print("1. Google")
    print("2. Bing")
    print("3. DuckDuckGo")
    choice = input("Enter your choice (1/2/3): ")

    if choice == '1':
        search_engine = "https://www.google.com/search?q="
    elif choice == '2':
        search_engine = "https://www.bing.com/search?q="
    elif choice == '3':
        search_engine = "https://duckduckgo.com/?q="
    else:
        print("Invalid choice. Defaulting to Google search.")
        search_engine = "https://www.google.com/search?q="
    
    search_term = input("Enter a word or link to search: ")
    url = search_engine + search_term
    subprocess.run(['start', url])
    input(set_text_color('white') + "Press Enter to return to the menu...")

def create_error():
    print(set_text_color('green'), end='')
    print("Create an error message:")
    error_type = input("Error type (Information/Warning/Critical): ").lower()
    message = input("Message: ")
    title = input("Title: ")
    
    if error_type == 'information':
        ctypes.windll.user32.MessageBoxW(0, message, title, 0x40 | 0x1)
    elif error_type == 'warning':
        ctypes.windll.user32.MessageBoxW(0, message, title, 0x30 | 0x1)
    elif error_type == 'critical':
        ctypes.windll.user32.MessageBoxW(0, message, title, 0x10 | 0x1)
    else:
        print("Invalid error type. Message not sent.")
    
    input(set_text_color('white') + "Press Enter to return to the menu...")

def send_message_to_all_computers():
    print(set_text_color('green'), end='')
    message = input("Enter the message to send to all computers on the network: ")
    subprocess.run(['msg', '*', message])
    input(set_text_color('white') + "Press Enter to return to the menu...")

def custom_cmd():
    print(set_text_color('green'), end='')
    print("Launching Custom CMD...")
    subprocess.run(['cmd.exe'])
    input(set_text_color('white') + "Press Enter to return to the menu...")

def image_converter():
    print(set_text_color('green'), end='')
    image_path = input("Enter the path to the image file: ")
    try:
        img = Image.open(image_path)
        img = img.convert('L')  # Convert image to grayscale
        width, height = img.size
        aspect_ratio = height / width
        new_width = 100
        new_height = int(aspect_ratio * new_width * 0.55)
        img = img.resize((new_width, new_height))
        
        ascii_chars = "@%#*+=-:. "
        ascii_image = ""
        
        for y in range(new_height):
            for x in range(new_width):
                pixel_value = img.getpixel((x, y))
                ascii_image += ascii_chars[int(pixel_value / 255 * (len(ascii_chars) - 1))]
            ascii_image += "\n"
        
        print(set_text_color('white'))
        print(ascii_image)
    except Exception as e:
        print(set_text_color('red') + f"Error converting image: {e}")
    
    input(set_text_color('white') + "Press Enter to return to the menu...")

def email_info():
    print(set_text_color('green'), end='')
    script_dir = os.path.dirname(os.path.realpath(__file__))
    email_info_script = os.path.join(script_dir, 'Email-Info.py')
    
    try:
        subprocess.run(['python', email_info_script], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Failed to open Email-Info.py: {e}")
    
    input(set_text_color('white') + "Press Enter to return to the menu...")
    
def Reverse_Image():
    script_dir = os.path.dirname(os.path.realpath(__file__))  # Get directory of the current script
    phone_info_script = os.path.join(script_dir, 'Reverse-Image.py')  # Construct path to Phone-Info.py
    
    print(set_text_color('green'))  # Set text color to green

    try:
        # Run the Phone-Info.py script
        result = subprocess.run(['python', phone_info_script], capture_output=True, text=True, check=True)
        
        # Print the output of Phone-Info.py
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"Failed to retrieve phone number info: {e}")

    input(set_text_color('reset') + "Press Enter to return to the menu...")

def phone_number_info():
    script_dir = os.path.dirname(os.path.realpath(__file__))  # Get directory of the current script
    phone_info_script = os.path.join(script_dir, 'Phone-Info.py')  # Construct path to Phone-Info.py
    
    print(set_text_color('green'))  # Set text color to green

    try:
        # Run the Phone-Info.py script
        result = subprocess.run(['python', phone_info_script], capture_output=True, text=True, check=True)
        
        # Print the output of Phone-Info.py
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"Failed to retrieve phone number info: {e}")

    input(set_text_color('reset') + "Press Enter to return to the menu...")


def Discord_Token_House():
        print("To launch this go to the asset folder and open Discord-Token-House.py")
        input(set_text_color('reset') + "Press Enter to return to the menu...")

    
def info_tab():
    print(set_text_color('green'), end='')
    print("Information Tab Options:")
    print("[1] -> Email Information")
    print("[2] -> Phone Number Information")
    choice = input("Enter your choice: ")
    
    if choice == '1':
        email_info()
    elif choice == '2':
        phone_number_info()
    else:
        print("Invalid choice. Returning to main menu.")
        input(set_text_color('white') + "Press Enter to return to the menu...")

def Discord_tab():
    print(set_text_color('green'), end='')
    print("Discord Token Tab:")
    print("[1] -> Discord Token House Changer(hypersquad)")
    print("[2] -> soon")
    choice = input("Enter your choice: ")
    
    if choice == '1':
        Discord_Token_House()
    elif choice == '2':
        phone_number_info()
    else:
        print("Invalid choice. Returning to main menu.")
        input(set_text_color('white') + "Press Enter to return to the menu...")

def main():
    if not is_admin():
        print(set_text_color('red') + "You need to run this script as an administrator.")
        input(set_text_color('white') + "Press Enter to exit...")
        return

    while True:
        print_header()
        print(set_text_color('green') + "")
        print("[1] -> Add User               [11] -> Show Cool Websites       [21] -> Custom CMD ")
        print("[2] -> List Users             [12] -> Show IP Addresses        [22] -> Image Converter ")
        print("[3] -> Change Password        [13] -> About Tool               [23] -> Info Tab ")
        print("[4] -> Delete User            [14] -> Open Discord Server Info [24] -> Reverse Image ")
        print("[5] -> Delete System32        [15] -> My Discord Token         [25] -> Discord Token Tab ")
        print("[6] -> Dancing Parrot         [16] -> Log Out User")
        print("[7] -> Open Kali Linux Page   [17] -> Email Information")
        print("[8] -> List WiFi Passwords    [18] -> Browser")
        print("[9] -> Send Webhook Message   [19] -> Create Error")
        print("[10] -> Send Webhook Image    [20] -> Send Message to All Computers on Network")
        print(set_text_color('blue') + "=" * 80)
        print(set_text_color('yellow') + f"Username: {get_username()}")  # Display username
        print(set_text_color('white'))

        prompt = set_text_color('yellow') + f"┌───({get_username()}@Claxes Tool!)"
        print(prompt)
        choice = input("└─$ ").strip()
        
        if choice == '1':
            add_user()
        elif choice == '2':
            list_users()
        elif choice == '3':
            change_password()
        elif choice == '4':
            delete_user()
        elif choice == '5':
            delete_system32()
        elif choice == '6':
            dancing_parrot()
        elif choice == '7':
            open_kali_linux_download_page()
        elif choice == '8':
            list_wifi_passwords()
        elif choice == '9':
            send_message_to_webhook()
        elif choice == '10':
            send_image_to_webhook()
        elif choice == '11':
            show_cool_websites()
        elif choice == '12':
            show_ip_addresses()
        elif choice == '13':
            about_tool()
        elif choice == '14':
            My_Discord_Token()
        elif choice == '15':
            My_Discord_Token()
        elif choice == '16':
            log_out_user()
        elif choice == '17':
            email_info()
        elif choice == '18':
            browser()
        elif choice == '19':
            create_error()
        elif choice == '20':
            send_message_to_all_computers()
        elif choice == '21':
            custom_cmd()
        elif choice == '22':
            image_converter()
        elif choice == '23':
            info_tab()
        elif choice == '24':
            Reverse_Image()
        elif choice == '25':
            Discord_tab()
        else:
            print(set_text_color('red') + "Invalid choice. Please try again.")
            input(set_text_color('white') + "Press Enter to continue...")

if __name__ == "__main__":
    main()
