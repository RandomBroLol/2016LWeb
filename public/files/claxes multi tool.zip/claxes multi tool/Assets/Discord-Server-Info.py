import requests

def set_text_color(color):
    colors = {
        'green': '\033[92m',
        'red': '\033[91m',
        'white': '\033[0m'
    }
    return colors.get(color, '\033[0m')

try:
    invite = input(set_text_color('green') + "\nServer Invitation -> " + set_text_color('white'))
    try:
        invite_code = invite.split("/")[-1]
    except:
        invite_code = invite
    response = requests.get(f"https://discord.com/api/v9/invites/{invite_code}")

    if response.status_code == 200:
        data = response.json()
        server_info = {
            "Type": data.get('type', 'None'),
            "Code": data.get('code', 'None'),
            "Inviter ID": data.get('inviter', {}).get('id', 'None'),
            "Inviter Username": data.get('inviter', {}).get('username', 'None'),
            "Inviter Avatar": data.get('inviter', {}).get('avatar', 'None'),
            "Inviter Discriminator": data.get('inviter', {}).get('discriminator', 'None'),
            "Inviter Public Flags": data.get('inviter', {}).get('public_flags', 'None'),
            "Inviter Flags": data.get('inviter', {}).get('flags', 'None'),
            "Inviter Banner": data.get('inviter', {}).get('banner', 'None'),
            "Inviter Accent Color": data.get('inviter', {}).get('accent_color', 'None'),
            "Inviter Global Name": data.get('inviter', {}).get('global_name', 'None'),
            "Inviter Banner Color": data.get('inviter', {}).get('banner_color', 'None'),
            "Expires At": data.get('expires_at', 'None'),
            "Flags": data.get('flags', 'None'),
            "Server ID": data.get('guild', {}).get('id', 'None'),
            "Server Name": data.get('guild', {}).get('name', 'None'),
            "Server Icon": data.get('guild', {}).get('icon', 'None'),
            "Server Features": data.get('guild', {}).get('features', 'None'),
            "Server Verification Level": data.get('guild', {}).get('verification_level', 'None'),
            "Server NSFW Level": data.get('guild', {}).get('nsfw_level', 'None'),
            "Server NSFW": data.get('guild', {}).get('nsfw', 'None')
        }

        for key, value in server_info.items():
            print(f"{key}: {value}")

    else:
        print(set_text_color('red') + f"Failed to retrieve server info. Status code: {response.status_code}" + set_text_color('white'))

except Exception as e:
    print(set_text_color('red') + f"An error occurred: {e}" + set_text_color('white'))

input("Press Enter to return to the menu...")
