from PIL import Image
import exifread
import os

def get_image_metadata(image_path):
    try:
        with open(image_path, 'rb') as f:
            tags = exifread.process_file(f)
            return tags
    except Exception as e:
        print(f"Error reading EXIF data: {e}")
        return None

def ask_for_image_path():
    while True:
        image_path = input("Enter the path to the image file: ").strip()
        if os.path.isfile(image_path):
            return image_path
        else:
            print("File not found. Please enter a valid image file path.")

def main():
    image_path = ask_for_image_path()
    print(f"Processing image: {image_path}")

    metadata = get_image_metadata(image_path)

    if metadata:
        print("\nEXIF Tags:")
        for tag, value in metadata.items():
            print(f"{tag}: {value}")
    else:
        print("No EXIF metadata found in the image.")

if __name__ == "__main__":
    main()
