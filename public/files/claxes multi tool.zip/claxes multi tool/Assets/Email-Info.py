import dns.resolver
import requests
import re
import datetime

# Define necessary functions directly within Email-Info.py
def Title(title):
    print(title)

def ErrorModule(error):
    print(f"Error occurred: {error}")

def current_time_hour():
    now = datetime.datetime.now()
    return now.strftime("%H:%M:%S")  # Format the current time as HH:MM:SS

# Define constants
BEFORE = ""
AFTER = ""
INPUT = ""
INFO_ADD = ""
RESET = ""
Continue = ""
Reset = ""
error_message = ""

try:
    def get_email_info(email):
        info = {}
        try:
            domain_all = email.split('@')[-1]
        except:
            domain_all = None

        try:
            name = email.split('@')[0]
        except:
            name = None

        try:
            domain = re.search(r"@([^@.]+)\.", email).group(1)
        except:
            domain = None
        try:
            tld = f".{email.split('.')[-1]}"
        except:
            tld = None

        try:
            mx_records = dns.resolver.resolve(domain_all, 'MX')
            mx_servers = [str(record.exchange) for record in mx_records]
            info["mx_servers"] = mx_servers
        except dns.resolver.NoAnswer:
            info["mx_servers"] = None
        except dns.resolver.NXDOMAIN:
            info["mx_servers"] = None

        try:
            spf_records = dns.resolver.resolve(domain_all, 'SPF')
            info["spf_records"] = [str(record) for record in spf_records]
        except dns.resolver.NoAnswer:
            info["spf_records"] = None
        except dns.resolver.NXDOMAIN:
            info["spf_records"] = None

        try:
            dmarc_records = dns.resolver.resolve(f'_dmarc.{domain_all}', 'TXT')
            info["dmarc_records"] = [str(record) for record in dmarc_records]
        except dns.resolver.NoAnswer:
            info["dmarc_records"] = None
        except dns.resolver.NXDOMAIN:
            info["dmarc_records"] = None

        if mx_servers:
            for server in mx_servers:
                if "google.com" in server:
                    info["google_workspace"] = True
                elif "outlook.com" in server:
                    info["microsoft_365"] = True

        try:
            response = requests.get(
                f"https://api.mailgun.net/v4/address/validate?address={email}",
                auth=("api", "YOUR_MAILGUN_API_KEY")
            )
            data = response.json()
            info["mailgun_validation"] = data
        except Exception as e:
            info["mailgun_validation"] = {"error": str(e)}

        return info, domain_all, domain, tld, name

    # Main script logic
    Title("Email Info")

    email = input(f"\n{BEFORE + current_time_hour() + AFTER} {INPUT} Email -> {RESET}")
    # Censored(email)  # You can implement Censored function if needed

    print(f"{BEFORE + current_time_hour() + AFTER} Waiting for information recovery... {RESET}")
    info, domain_all, domain, tld, name = get_email_info(email)

    try:
        mx_servers = info["mx_servers"]
        mx_servers = ' / '.join(mx_servers) if mx_servers else None
    except Exception as e:
        mx_servers = None

    try:
        spf_records = info["spf_records"]
    except:
        spf_records = None

    try:
        dmarc_records = info["dmarc_records"]
        dmarc_records = ' / '.join(dmarc_records) if dmarc_records else None
    except:
        dmarc_records = None

    try:
        google_workspace = info.get("google_workspace", None)
    except:
        google_workspace = None

    try:
        mailgun_validation = info.get("mailgun_validation", None)
        mailgun_validation = ' / '.join(mailgun_validation) if mailgun_validation else None
    except:
        mailgun_validation = None

    print(f"""
    {INFO_ADD} Email      : {email}
    {INFO_ADD} Name       : {name}
    {INFO_ADD} Domain     : {domain}
    {INFO_ADD} Tld        : {tld}
    {INFO_ADD} Domain All : {domain_all}
    {INFO_ADD} Servers    : {mx_servers}
    {INFO_ADD} Spf        : {spf_records}
    {INFO_ADD} Dmarc      : {dmarc_records}
    {INFO_ADD} Workspace  : {google_workspace}
    {INFO_ADD} Mailgun    : {mailgun_validation}
    """)

    Continue()
    Reset()

except Exception as e:
    ErrorModule(e)
