import os
import subprocess

def set_text_color(color):
    colors = {
        'green': '\033[92m',
        'white': '\033[0m'
    }
    return colors.get(color, '\033[0m')

def run_custom_cmd():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(set_text_color('green'))
    os.system('cmd /k "title Claxes CMD && color 0A"')

if __name__ == "__main__":
    run_custom_cmd()
